<script lang="ts">
	import { onMount } from 'svelte';
	import { browser } from '$app/environment';

	let groupID = '';
	let privateKey = '';
	let generatedUrl = '';
	let showUrlDiv = false;
	let isLoading = false;
	let error = '';
	let escapeChars = false;

	// Character processing function converted from Python
	function specialCharHandle(bib: string): string {
		const replacements: [string, string][] = [
			['á', '{\\\'{a}}'], ['ć', '{\\\'{c}}'], ['é', '{\\\'{e}}'], ['ǵ', '{\\\'{g}}'],
			['í', '{\\\'{i}}'], ['ń', '{\\\'{n}}'], ['ó', '{\\\'{o}}'], ['ŕ', '{\\\'{r}}'],
			['ś', '{\\\'{s}}'], ['ú', '{\\\'{u}}'], ['ẃ', '{\\\'{w}}'], ['ý', '{\\\'{y}}'],
			['ź', '{\\\'{z}}'], ['Á', '{\\\'{A}}'], ['Ć', '{\\\'{C}}'], ['É', '{\\\'{E}}'],
			['Ǵ', '{\\\'{G}}'], ['Í', '{\\\'{I}}'], ['Ń', '{\\\'{N}}'], ['Ó', '{\\\'{O}}'],
			['Ŕ', '{\\\'{R}}'], ['Ś', '{\\\'{S}}'], ['Ú', '{\\\'{U}}'], ['Ẃ', '{\\\'{W}}'],
			['Ý', '{\\\'{Y}}'], ['Ź', '{\\\'{Z}}'], ['ä', '{\\\"{a}}'], ['ë', '{\\\"{e}}'],
			['ï', '{\\\"{i}}'], ['ö', '{\\\"{o}}'], ['ü', '{\\\"{u}}'], ['ÿ', '{\\\"{y}}'],
			['Ä', '{\\\"{A}}'], ['Ë', '{\\\"{E}}'], ['Ï', '{\\\"{I}}'], ['Ö', '{\\\"{O}}'],
			['Ü', '{\\\"{U}}'], ['Ÿ', '{\\\"{Y}}'], ['à', '{\\\`{a}}'], ['è', '{\\\`{e}}'],
			['ì', '{\\\`{i}}'], ['ò', '{\\\`{o}}'], ['ù', '{\\\`{u}}'], ['À', '{\\\`{A}}'],
			['È', '{\\\`{E}}'], ['Ì', '{\\\`{I}}'], ['Ò', '{\\\`{O}}'], ['Ù', '{\\\`{U}}'],
			['â', '{\\\^{a}}'], ['ê', '{\\\^{e}}'], ['î', '{\\\^{i}}'], ['ô', '{\\\^{o}}'],
			['û', '{\\\^{u}}'], ['Â', '{\\\^{A}}'], ['Ê', '{\\\^{E}}'], ['Î', '{\\\^{I}}'],
			['Ô', '{\\\^{O}}'], ['Û', '{\\\^{U}}'], ['ã', '{\\\~{a}}'], ['ẽ', '{\\\~{e}}'],
			['ĩ', '{\\\~{i}}'], ['õ', '{\\\~{o}}'], ['ũ', '{\\\~{u}}'], ['Ã', '{\\\~{A}}'],
			['Ẽ', '{\\\~{E}}'], ['Ĩ', '{\\\~{I}}'], ['Õ', '{\\\~{O}}'], ['Ũ', '{\\\~{U}}'],
			['ç', '{\\\c{c}}'], ['Ç', '{\\\c{C}}'], ['ñ', '{\\\~{n}}'], ['Ñ', '{\\\~{N}}'],
			['ß', '{\\\ss}'],
		];

		let result = bib;
		for (const [pattern, replacement] of replacements) {
			result = result.split(pattern).join(replacement);
		}
		return result;
	}

	async function fetchPage(url: string): Promise<string> {
		try {
			let response = await fetch(url, {
				headers: {
					'User-Agent': 'Mozilla/5.0 (compatible; Zootle/1.0; +https://zootle.me)',
					'Accept': 'text/plain, application/bibtex, */*',
					'Accept-Charset': 'utf-8',
					'Accept-Language': 'en-US,en;q=0.9',
					'Cache-Control': 'no-cache'
				}
			});
			
			// If first attempt fails, try without headers
			if (!response.ok && response.status === 403) {
				response = await fetch(url);
			}
			
			if (response.ok) {
				return await response.text();
			}
			return '';
		} catch (error) {
			console.error(`Error fetching ${url}:`, error);
			return '';
		}
	}

	async function fetchZoteroData(groupId: string, privateKey: string = '', escape: boolean = false) {
		isLoading = true;
		error = '';

		try {
			console.log('Zootle API request:', { groupID: groupId, privateKey: privateKey ? '[REDACTED]' : 'none', escape });

			if (!groupId) {
				throw new Error('Group ID is required');
			}

			const limit = 100;
			let baseUrl = `https://api.zotero.org/groups/${groupId}/items/top?format=bibtex&style=numeric&limit=${limit}`;
			if (privateKey) {
				baseUrl += `&key=${privateKey}`;
			}

			console.log('Fetching from Zotero API:', baseUrl.replace(privateKey, '[REDACTED]'));

			// Fetch first page to get total count
			let firstResponse = await fetch(baseUrl, {
				headers: {
					'User-Agent': 'Mozilla/5.0 (compatible; Zootle/1.0; +https://zootle.me)',
					'Accept': 'text/plain, application/bibtex, */*',
					'Accept-Charset': 'utf-8',
					'Accept-Language': 'en-US,en;q=0.9',
					'Cache-Control': 'no-cache'
				}
			});
			
			// If first attempt fails, try without headers (like the original Python code)
			if (!firstResponse.ok && firstResponse.status === 403) {
				console.log('First attempt failed with 403, trying without headers...');
				firstResponse = await fetch(baseUrl);
			}
			
			console.log('Zotero API response status:', firstResponse.status);
			console.log('Zotero API response headers:', Object.fromEntries(firstResponse.headers.entries()));
			
			if (!firstResponse.ok) {
				const errorText = await firstResponse.text();
				console.log('Zotero API error response:', errorText);
				throw new Error(`HTTP ${firstResponse.status}: ${firstResponse.statusText}`);
			}

			const totalResults = parseInt(firstResponse.headers.get('Total-Results') || '0');
			let allData = await firstResponse.text();

			// Fetch additional pages in parallel
			const startValues = Array.from({ length: Math.floor(totalResults / limit) }, (_, i) => (i + 1) * limit);
			const additionalUrls = startValues.map(start => `${baseUrl}&start=${start}`);

			const additionalResponses = await Promise.all(
				additionalUrls.map(url => fetchPage(url))
			);

			allData += additionalResponses.join('');

			if (escape) {
				allData = specialCharHandle(allData);
			}

			// Create and download the file
			const blob = new Blob([allData], { type: 'text/plain' });
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = 'references.bib';
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);

		} catch (err) {
			error = err instanceof Error ? err.message : 'An error occurred';
		} finally {
			isLoading = false;
		}
	}

	function generateLink() {
		if (!groupID.trim()) {
			error = 'Please enter a Group ID';
			return;
		}

		showUrlDiv = true;
		// Note: URL generation is now client-side only
		generatedUrl = `Client-side processing - no URL generated`;
		error = '';
	}

	function copyToClipboard() {
		if (browser && navigator.clipboard) {
			navigator.clipboard.writeText(generatedUrl);
		}
	}

	onMount(() => {
		// Initialize tooltips if Bootstrap is available
		if (browser && (window as any).bootstrap) {
			const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
			Array.from(tooltipTriggerList).forEach(el => {
				new (window as any).bootstrap.Tooltip(el);
			});
		}
	});
</script>

<svelte:head>
	<title>zootle</title>
	<meta name="description" content="Generate Download Links for Zotero groups with >100 entries" />
	<meta name="keywords" content="Zotero, Zootle, Zoole.me, ZootleMe, Zotero Group Library, Zotero Overleaf Integration" />
	
	<!-- Open Graph Meta Tags -->
	<meta property="og:title" content="zootle" />
	<meta property="og:description" content="Generate Download Links for Zotero groups with >100 entries" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://zootle.me" />
	
	<!-- Twitter Meta Tags -->
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:title" content="zootle" />
	<meta name="twitter:description" content="Generate Download Links for Zotero groups with >100 entries" />
	
	<link href="https://fonts.googleapis.com/css?family=Playfair Display" rel="stylesheet" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</svelte:head>

<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
	<div id="title-div" class="row">
		<main class="px-3">
			<h1 id="zootle-title">zootle</h1>
			<p class="lead">Generate Download Links for <a href="https://www.zotero.org/">Zotero</a> groups with >100 entries</p>
		</main>
	</div>
	
	<div id="main-div" class="row justify-content-center">
		<div class="col col-10">
			<form on:submit|preventDefault>
				<div class="form-group row mb-3">
					<div class="col">
						<label for="groupID" class="">Group ID</label>
						<input 
							type="text" 
							class="form-control" 
							id="groupID" 
							bind:value={groupID}
							autocomplete="off"
						/>
					</div>
				</div>
				
				<div class="form-group row mb-3">
					<div class="col">
						<label for="privateID" class="">Private Key</label>
						<div id="privateKeyHelp" class="form-text">
							Optionally, Generate Private Keys in <a href="https://www.zotero.org/settings/keys">Zotero account settings</a>
						</div>
						<input 
							type="text" 
							class="form-control" 
							id="privateID" 
							bind:value={privateKey}
							autocomplete="off"
						/>
					</div>
				</div>
				
				<div class="form-group row mb-3">
					<div class="col">
						<div class="form-check">
							<input 
								class="form-check-input" 
								type="checkbox" 
								id="escapeChars" 
								bind:checked={escapeChars}
							/>
							<label class="form-check-label" for="escapeChars">
								Escape special characters
							</label>
						</div>
					</div>
				</div>
				
				<div class="form-group row mb-3">
					<div class="col">
						<button 
							id="generate-button" 
							type="button" 
							class="btn btn-primary"
							on:click={generateLink}
							disabled={isLoading}
						>
							{#if isLoading}
								<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
								Loading...
							{:else}
								Generate URL
							{/if}
						</button>
					</div>
				</div>
			</form>
			
			{#if error}
				<div class="alert alert-danger" role="alert">
					{error}
				</div>
			{/if}
			
			{#if showUrlDiv}
				<div class="col col-auto" id="url-button-div">
					<div class="form-group row mb-3">
						<label for="url-button" class="">Status</label>
						<div class="url-container">
							<div class="alert alert-info" role="alert">
								<strong>Client-side processing enabled</strong><br>
								The download will be processed directly in your browser. No server-side URL generation is needed.
							</div>
						</div>
					</div>
					<p id="import">
						To Import into <a href="https://www.overleaf.com">Overleaf</a>, select New File -> From External URL
					</p>
					
					<div class="form-group row mb-3">
						<div class="col">
							<button 
								type="button" 
								class="btn btn-success"
								on:click={() => fetchZoteroData(groupID, privateKey, escapeChars)}
								disabled={isLoading}
							>
								{#if isLoading}
									<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
									Downloading...
								{:else}
									Download BibTeX File
								{/if}
							</button>
						</div>
					</div>
				</div>
			{/if}
		</div>
	</div>
</div>

<style lang="scss">
	/* Custom default button */
	.btn-secondary,
	.btn-secondary:hover,
	.btn-secondary:focus {
		color: #333;
		text-shadow: none; /* Prevent inheritance from `body` */
	}

	/* Base structure */
	body {
		text-shadow: 0 0.05rem 0.1rem rgba(0, 0, 0, 0.5);
		box-shadow: inset 0 0 5rem rgba(0, 0, 0, 0.5);
		background-color: #000;
		font-family: 'Playfair Display';
	}

	.books {
		height: 100%;
		width: 100%;
	}

	h1 {
		font-size: 7rem;
	}

	.cover-container {
		max-width: 42em;
	}

	#url-button-div {
		display: block;
	}

	#privateKeyHelp, #import {
		font-size: 0.8rem;
		color: #bcbcbd;
		margin-bottom: 0.5rem;
	}

	.url-container {
		display: flex;
		flex-direction: column;
		gap: 0.5rem;
	}

	.selectable-url {
		user-select: text;
		-webkit-user-select: text;
		-moz-user-select: text;
		-ms-user-select: text;
		cursor: text;
	}

	.url-disclaimer {
		font-size: 0.75rem;
		color: #bcbcbd;
		font-style: italic;
	}

	#zootle-title {
		color: #ff7477;
	}

	.alert {
		margin-top: 1rem;
	}

	.btn {
		&:disabled {
			opacity: 0.6;
		}
	}

	.spinner-border-sm {
		margin-right: 0.5rem;
	}
</style>
