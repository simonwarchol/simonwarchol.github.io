import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';

// Character processing function converted from Python
function specialCharHandle(bib: string): string {
	const replacements: [string, string][] = [
		['á', '{\\\'{a}}'], ['ć', '{\\\'{c}}'], ['é', '{\\\'{e}}'], ['ǵ', '{\\\'{g}}'],
		['í', '{\\\'{i}}'], ['ń', '{\\\'{n}}'], ['ó', '{\\\'{o}}'], ['ŕ', '{\\\'{r}}'],
		['ś', '{\\\'{s}}'], ['ú', '{\\\'{u}}'], ['ẃ', '{\\\'{w}}'], ['ý', '{\\\'{y}}'],
		['ź', '{\\\'{z}}'], ['Á', '{\\\'{A}}'], ['Ć', '{\\\'{C}}'], ['É', '{\\\'{E}}'],
		['Ǵ', '{\\\'{G}}'], ['Í', '{\\\'{I}}'], ['Ń', '{\\\'{N}}'], ['Ó', '{\\\'{O}}'],
		['Ŕ', '{\\\'{R}}'], ['Ś', '{\\\'{S}}'], ['Ú', '{\\\'{U}}'], ['Ẃ', '{\\\'{W}}'],
		['Ý', '{\\\'{Y}}'], ['Ź', '{\\\'{Z}}'], ['ä', '{\\\"{a}}'], ['ë', '{\\\"{e}}'],
		['ï', '{\\\"{i}}'], ['ö', '{\\\"{o}}'], ['ü', '{\\\"{u}}'], ['ÿ', '{\\\"{y}}'],
		['Ä', '{\\\"{A}}'], ['Ë', '{\\\"{E}}'], ['Ï', '{\\\"{I}}'], ['Ö', '{\\\"{O}}'],
		['Ü', '{\\\"{U}}'], ['Ÿ', '{\\\"{Y}}'], ['à', '{\\\`{a}}'], ['è', '{\\\`{e}}'],
		['ì', '{\\\`{i}}'], ['ò', '{\\\`{o}}'], ['ù', '{\\\`{u}}'], ['À', '{\\\`{A}}'],
		['È', '{\\\`{E}}'], ['Ì', '{\\\`{I}}'], ['Ò', '{\\\`{O}}'], ['Ù', '{\\\`{U}}'],
		['â', '{\\\^{a}}'], ['ê', '{\\\^{e}}'], ['î', '{\\\^{i}}'], ['ô', '{\\\^{o}}'],
		['û', '{\\\^{u}}'], ['Â', '{\\\^{A}}'], ['Ê', '{\\\^{E}}'], ['Î', '{\\\^{I}}'],
		['Ô', '{\\\^{O}}'], ['Û', '{\\\^{U}}'], ['ã', '{\\\~{a}}'], ['ẽ', '{\\\~{e}}'],
		['ĩ', '{\\\~{i}}'], ['õ', '{\\\~{o}}'], ['ũ', '{\\\~{u}}'], ['Ã', '{\\\~{A}}'],
		['Ẽ', '{\\\~{E}}'], ['Ĩ', '{\\\~{I}}'], ['Õ', '{\\\~{O}}'], ['Ũ', '{\\\~{U}}'],
		['ç', '{\\\c{c}}'], ['Ç', '{\\\c{C}}'], ['ñ', '{\\\~{n}}'], ['Ñ', '{\\\~{N}}'],
		['ß', '{\\\ss}'],
		// Add more replacements as needed - this is a subset for brevity
	];

	let result = bib;
	for (const [pattern, replacement] of replacements) {
		// Use string replace instead of regex to avoid escaping issues
		result = result.split(pattern).join(replacement);
	}
	return result;
}

async function fetchPage(url: string): Promise<string> {
	try {
		let response = await fetch(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0 (compatible; Zootle/1.0; +https://zootle.me)',
				'Accept': 'text/plain, application/bibtex, */*',
				'Accept-Charset': 'utf-8',
				'Accept-Language': 'en-US,en;q=0.9',
				'Cache-Control': 'no-cache'
			}
		});
		
		// If first attempt fails, try without headers
		if (!response.ok && response.status === 403) {
			response = await fetch(url);
		}
		
		if (response.ok) {
			return await response.text();
		}
		return '';
	} catch (error) {
		console.error(`Error fetching ${url}:`, error);
		return '';
	}
}

export const GET: RequestHandler = async ({ url }) => {
	const groupID = url.searchParams.get('groupID');
	const privateKey = url.searchParams.get('privateKey') || '';
	const escape = url.searchParams.get('escape')?.toLowerCase() === 'true';

	console.log('Zootle API request:', { groupID, privateKey: privateKey ? '[REDACTED]' : 'none', escape });

	if (!groupID) {
		return json({ error: 'Group ID is required' }, { status: 400 });
	}

	try {
		const limit = 100;
		let baseUrl = `https://api.zotero.org/groups/${groupID}/items/top?format=bibtex&style=numeric&limit=${limit}`;
		if (privateKey) {
			baseUrl += `&key=${privateKey}`;
		}

		console.log('Fetching from Zotero API:', baseUrl.replace(privateKey, '[REDACTED]'));

		// Fetch first page to get total count
		let firstResponse = await fetch(baseUrl, {
			headers: {
				'User-Agent': 'Mozilla/5.0 (compatible; Zootle/1.0; +https://zootle.me)',
				'Accept': 'text/plain, application/bibtex, */*',
				'Accept-Charset': 'utf-8',
				'Accept-Language': 'en-US,en;q=0.9',
				'Cache-Control': 'no-cache'
			}
		});
		
		// If first attempt fails, try without headers (like the original Python code)
		if (!firstResponse.ok && firstResponse.status === 403) {
			console.log('First attempt failed with 403, trying without headers...');
			firstResponse = await fetch(baseUrl);
		}
		
		console.log('Zotero API response status:', firstResponse.status);
		console.log('Zotero API response headers:', Object.fromEntries(firstResponse.headers.entries()));
		
		if (!firstResponse.ok) {
			const errorText = await firstResponse.text();
			console.log('Zotero API error response:', errorText);
			return json(
				{ error: `HTTP ${firstResponse.status}: ${firstResponse.statusText}`, details: errorText },
				{ status: firstResponse.status }
			);
		}

		const totalResults = parseInt(firstResponse.headers.get('Total-Results') || '0');
		let allData = await firstResponse.text();

		// Fetch additional pages in parallel
		const startValues = Array.from({ length: Math.floor(totalResults / limit) }, (_, i) => (i + 1) * limit);
		const additionalUrls = startValues.map(start => `${baseUrl}&start=${start}`);

		const additionalResponses = await Promise.all(
			additionalUrls.map(url => fetchPage(url))
		);

		allData += additionalResponses.join('');

		if (escape) {
			allData = specialCharHandle(allData);
		}

		return new Response(allData, {
			headers: {
				'Content-Type': 'text/plain',
				'Content-Disposition': 'attachment; filename="references.bib"'
			}
		});

	} catch (error) {
		console.error('Error fetching Zotero data:', error);
		return json(
			{ error: 'An error occurred while fetching data from Zotero' },
			{ status: 500 }
		);
	}
};
