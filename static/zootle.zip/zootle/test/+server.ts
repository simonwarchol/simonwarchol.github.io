import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ url }) => {
	const groupID = url.searchParams.get('groupID');
	
	if (!groupID) {
		return json({ error: 'Group ID is required' }, { status: 400 });
	}

	// Test with a simple public group first
	const testUrl = `https://api.zotero.org/groups/${groupID}/items/top?format=bibtex&style=numeric&limit=1`;
	
	try {
		console.log('Testing Zotero API with:', testUrl);
		
		// Try with headers first
		let response = await fetch(testUrl, {
			headers: {
				'User-Agent': 'Mozilla/5.0 (compatible; Zootle/1.0; +https://zootle.me)',
				'Accept': 'text/plain, application/bibtex, */*'
			}
		});
		
		if (!response.ok) {
			console.log('With headers failed:', response.status, response.statusText);
			// Try without headers
			response = await fetch(testUrl);
		}
		
		if (response.ok) {
			const text = await response.text();
			return json({
				success: true,
				status: response.status,
				headers: Object.fromEntries(response.headers.entries()),
				content: text.substring(0, 500) + '...' // First 500 chars
			});
		} else {
			const errorText = await response.text();
			return json({
				success: false,
				status: response.status,
				statusText: response.statusText,
				error: errorText
			}, { status: response.status });
		}
		
	} catch (error) {
		console.error('Test error:', error);
		return json({
			success: false,
			error: error instanceof Error ? error.message : 'Unknown error'
		}, { status: 500 });
	}
};
